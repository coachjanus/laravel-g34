{{-- resources/views/livewire/main/cart-update.blade.php --}}
<input wire:model="quantity"
        type="number" min="1" max="7"
        wire:change="updateCart"
        class="w-full font-semibold text-center text-gray-700 bg-indigo-200 lg:rounded outline-none focus:outline-none hover:text-black focus:text-black"  />

