{{-- resources/views/livewire/main/cart-counter.blade.php --}}
<span class="flex h-6 items-center px-2 rounded-lg border border-gray-200 hover:border-gray-300 focus:outline-none hover:shadow-inner">
<svg class="h-6 w-6 leading-none text-gray-400 stroke-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
    </svg>
    <span class="pl-1 text-gray-500 text-md" >{{ $cart_count }}</span>
</span>
